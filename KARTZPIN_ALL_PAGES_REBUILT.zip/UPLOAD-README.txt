KARTZPIN SUPPORT PAGES — UPLOAD GUIDE

Upload these 9 files directly into the ROOT of your GitHub repository (same level as index.html):
about.html
contact.html
privacy-policy.html
terms.html
disclaimer.html
faq.html
how-to-download.html
pages.css
pages.js

Do not upload the ZIP itself. Extract it first, then upload the 9 files.
Do not put them inside a folder. Do not replace index.html, styles.css, or script.js.
All pages link to ./pages.css and ./pages.js.

After upload and Commit changes, wait for GitHub Pages to publish:
https://thekartz48-glitch.github.io/kartzpin-downloader/about.html

Add links to these pages in your existing homepage navigation/footer separately.

Before launch: add a real monitored contact method; make the privacy policy accurate for actual hosting, backend, logs, analytics, cookies and third parties; review legal terms for your jurisdiction. Templates are not legal advice. A static page does not send contact messages without a working form/backend. Do not facilitate unauthorised downloads or bypass private settings, logins, DRM, or technical restrictions. KartzPin is not affiliated with Pinterest.
